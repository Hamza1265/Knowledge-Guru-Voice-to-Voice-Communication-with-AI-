import { ILinearRampToValueAutomationEvent } from './linear-ramp-to-value-automation-event';

export interface IExtendedLinearRampToValueAutomationEvent extends ILinearRampToValueAutomationEvent {
    readonly insertTime: number;
}
