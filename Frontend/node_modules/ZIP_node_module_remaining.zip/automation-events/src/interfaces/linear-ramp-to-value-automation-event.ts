export interface ILinearRampToValueAutomationEvent {
    readonly endTime: number;

    readonly type: 'linearRampToValue';

    readonly value: number;
}
