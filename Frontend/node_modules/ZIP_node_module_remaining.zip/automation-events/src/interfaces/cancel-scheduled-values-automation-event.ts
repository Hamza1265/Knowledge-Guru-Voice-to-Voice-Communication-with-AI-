export interface ICancelScheduledValuesAutomationEvent {
    readonly cancelTime: number;

    readonly type: 'cancelScheduledValues';
}
