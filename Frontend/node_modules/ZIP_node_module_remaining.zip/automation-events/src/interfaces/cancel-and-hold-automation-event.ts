export interface ICancelAndHoldAutomationEvent {
    readonly cancelTime: number;

    readonly type: 'cancelAndHold';
}
