export interface ISetValueAutomationEvent {
    readonly startTime: number;

    readonly type: 'setValue';

    readonly value: number;
}
