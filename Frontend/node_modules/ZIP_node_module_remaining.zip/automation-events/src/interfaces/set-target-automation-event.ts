export interface ISetTargetAutomationEvent {
    readonly startTime: number;

    readonly target: number;

    readonly timeConstant: number;

    readonly type: 'setTarget';
}
