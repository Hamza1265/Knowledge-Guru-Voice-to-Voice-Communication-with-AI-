import { IExponentialRampToValueAutomationEvent } from './exponential-ramp-to-value-automation-event';

export interface IExtendedExponentialRampToValueAutomationEvent extends IExponentialRampToValueAutomationEvent {
    readonly insertTime: number;
}
