# broker-factory

**A little factory function to create a broker for a JSON-RPC based Web Worker.**

[![version](https://img.shields.io/npm/v/broker-factory.svg?style=flat-square)](https://www.npmjs.com/package/broker-factory)
