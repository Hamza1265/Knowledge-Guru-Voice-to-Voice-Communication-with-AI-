export const PORT_MAP: WeakMap<MessagePort, number> = new WeakMap();
